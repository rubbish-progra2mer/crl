{
  "budget": {"stated": true, "enforced": true},
  "house_rule": {"stated": true, "enforced": true},
  "room_type": {"stated": false, "enforced": false},
  "cuisine": {"stated": false, "enforced": false},
  "transportation": {"stated": false, "enforced": false},
  "distinct_restaurants": {"stated": true, "enforced": true},
  "distinct_attractions": {"stated": true, "enforced": true}
}