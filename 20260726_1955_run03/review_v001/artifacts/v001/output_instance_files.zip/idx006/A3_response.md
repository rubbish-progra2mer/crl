{
  "budget": {"stated": true, "enforced": true},
  "house_rule": {"stated": false, "enforced": false},
  "room_type": {"stated": false, "enforced": false},
  "cuisine": {"stated": false, "enforced": false},
  "transportation": {"stated": false, "enforced": false},
  "distinct_restaurants": {"stated": true, "enforced": true},
  "distinct_attractions": {"stated": true, "enforced": true}
}