# CRL Contract v2 本机环境事实

## 1. 文档职责

本文只记录当前宿主可用的密钥位置、注入方式、硬件、运行时和工具事实。科研流程、模型资格、实验充分性、资源决策和付费询问边界只见 `CRL.md`。

这些事实不是启动检查清单，也不要求每轮复验。实际实验遇到差异时，以该次命令的真实输出为准。

## 2. 固定位置

- 产品根：`D:\Desktop\crl`
- 机器根：`D:\Desktop\crl\crl_agent_v3`
- 共享知识库：`D:\Desktop\crl\knowledge_base`
- 默认 Python：`D:\Desktop\crl\env\crl_agent_v3\python.exe`
- 依赖快照：`CRL_ENVIRONMENT_LOCK.txt`
- GGUF 模型：`D:\Desktop\crl\models\gguf`
- llama.cpp 运行时：`D:\Desktop\crl\runtimes\llama.cpp\b10107`

## 3. 当前硬件与 Python

- 操作系统：Microsoft Windows 11 IoT 企业版 LTSC，64 位。
- CPU：13th Gen Intel Core i5-13490F，10 核、16 逻辑处理器。
- 内存：约 31.84 GiB。
- GPU：NVIDIA GeForce RTX 5060 Ti，约 16 GiB 显存，计算能力 12.0。
- NVIDIA 驱动：591.86；驱动报告 CUDA 13.1。
- Python：3.11.15。
- Python CUDA 运行时由锁定依赖提供，不要求系统存在 `nvcc`。

机器本体工具默认使用产品根 `env\crl_agent_v3` 中的外置共享环境，不调用来源不明的裸 `python`。现有研究依赖与共享环境兼容时可以直接复用；实验需要新增、升级或冲突版本时，必须优先使用当前 Run 的隔离环境或用户指定的外部隔离环境，不能先污染共享环境。不静默升级 Python、PyTorch、sentence-transformers、transformers、tokenizers 或向量编码语义；这些变化可能使机器工具或派生索引失效。

## 4. 本地模型与运行时

当前可用资源包括：

- Ollama 及其本地模型：`bge-m3:latest`、`qwen3:4b`、`qwen2.5:7b`、`qwen3:8b`；
- GGUF 模型：`D:\Desktop\crl\models\gguf\Qwen3-8B-Q4_K_M.gguf`；
- llama.cpp CUDA 运行时：`D:\Desktop\crl\runtimes\llama.cpp\b10107`；
- NVIDIA GPU、本地 CPU 和文件系统。

这些资源可以按 Claim 需要自主使用，不因存在而必须调用。实际使用时，在 Seed 或实验声明文件中记录模型来源、版本或 revision、量化格式和可取得的文件身份。

## 5. 通用工具与网络

- Git 已安装，可用于 Run 局部源码和外部公开代码获取。
- 当前宿主可访问开放网络，具体站点、登录状态和速率限制以使用时事实为准。
- Codex App 是当前交互与工具宿主，不是正式规约限定的模型。
- Windows PowerShell 5.1 读取 Markdown 时必须显式使用 `Get-Content -Encoding UTF8`；可用 `tools/run_python_utf8.ps1` 执行已保存的 Python 脚本。

## 6. 外部 API 与密钥注入

产品根 `.env` 当前保存 DeepSeek 密钥变量名 `DEEPSEEK_API_KEY`。密钥只能临时注入需要它的当前进程，不得回显，不得放入命令行参数、Markdown、源码、Run 文件、原始输出、Reviewer 材料或知识库。

外部 API 实验应保存脱敏后的请求配置、原始响应、provider、请求模型、可取得的响应模型身份、时间、调用次数、Token、费用和错误事实。无法取得的字段如实说明不可见。资源授权和何时询问用户只见 `CRL.md`，本文不复制固定费用数字。

## 7. Run 局部依赖与数据

优先复用共享环境中已经兼容的依赖；一旦需要安装新包、改变版本或存在冲突风险，就在当前 Run 内或用户指定位置建立隔离环境，并记录路径、Python、关键依赖和创建方式。不要把完整虚拟环境作为 Reviewer 材料；例外环境不升级为新的全局默认，也不得反向改变机器工具所用共享环境。

实验所需公开代码、数据集和模型可下载到当前 Run 的明确目录或用户指定的外部缓存。不得覆盖未知数据，不得把跨 Run 科研材料放入共享缓存，不得把下载行为扩张成知识库维护。明显大容量、明显高费用、新账号/密钥/权限或危险环境修改按 `CRL.md` 先询问用户。
