from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest


PROJECT_ROOT = Path(__file__).resolve().parents[1]
RUNNER = PROJECT_ROOT / "tools" / "run_local_experiment.py"


def make_run(tmp_path: Path, *, status: str = "ACTIVE") -> tuple[Path, Path]:
    product_root = tmp_path / "product"
    product_root.mkdir(parents=True, exist_ok=True)
    run = product_root / "20260731_1200_run01"
    run.mkdir()
    controls = {
        "RUN_CHARTER.md": (
            f"# Run Charter\n\nRUN_ID: {run.name}\n"
            "CRL_CONTRACT_VERSION: 2\n"
            "DEFAULT_DOMAIN: TEXT_AND_TOOL_LLM_AGENT\n"
            "MODE: AUTONOMOUS\nCURRENT_VERSION: v001\n"
        ),
        "RUN_STATUS.md": (
            f"# Run Status\n\nRUN_ID: {run.name}\nSTATUS: {status}\n"
            "MODE: AUTONOMOUS\nCURRENT_VERSION: v001\n"
        ),
        "RUN_LEDGER.md": "# Run Ledger\n\n- EVENT: TEST_RUN_CREATED\n",
    }
    for name, content in controls.items():
        (run / name).write_bytes(content.encode("utf-8"))
    return product_root, run


def set_current_version(run: Path, version: str) -> None:
    status = (run / "RUN_STATUS.md").read_text(encoding="utf-8")
    status = status.replace("CURRENT_VERSION: v001", f"CURRENT_VERSION: {version}")
    (run / "RUN_STATUS.md").write_text(status, encoding="utf-8", newline="\n")


def record_successful_attempt(
    product: Path,
    run: Path,
    version: str,
    source: Path,
    *,
    attempt_id: str = "attempt-001",
) -> subprocess.CompletedProcess[bytes]:
    capture = run / f"experiment_{version}" / "attempts" / attempt_id
    output = capture / "result.txt"
    implementation = run / f"implementation_{version}" / "method.py"
    implementation.parent.mkdir(parents=True, exist_ok=True)
    if not implementation.exists():
        implementation.write_bytes(b"def method():\n    return 'test implementation'\n")
    command = [
        sys.executable,
        "-c",
        (
            "from pathlib import Path; import sys; "
            "Path(sys.argv[1]).write_text('actual output\\n', encoding='utf-8'); "
            "print('completed')"
        ),
        str(output),
    ]
    return subprocess.run(
        [
            sys.executable,
            str(RUNNER),
            "--product-root",
            str(product),
            "--run-root",
            str(run),
            "--version",
            version,
            "--attempt-id",
            attempt_id,
            "--cwd",
            str(source.parent),
            "--implementation-file",
            str(implementation),
            "--input",
            str(source),
            "--output",
            str(output),
            "--seed-not-set",
            "--",
            *command,
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def make_directory_reparse_point(link: Path, target: Path) -> None:
    target.mkdir(parents=True, exist_ok=True)
    completed = subprocess.run(
        ["cmd", "/c", "mklink", "/J", str(link), str(target)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if completed.returncode != 0:
        pytest.skip("当前 Windows 环境不允许创建 Junction，跳过重解析点专用场景")


def make_file_symlink(link: Path, target: Path) -> None:
    try:
        link.symlink_to(target)
    except OSError:
        pytest.skip("当前环境不允许创建文件符号链接，跳过符号链接专用场景")
