from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path

import pytest

from conftest import make_directory_reparse_point, make_run
from crl_v3.experiment import experiment_material_errors
from crl_v3.workspace import ResearchWorkspace
import tools.run_local_experiment as runner_module


PROJECT_ROOT = Path(__file__).resolve().parents[1]
RUNNER = PROJECT_ROOT / "tools" / "run_local_experiment.py"


def _fixture(tmp_path: Path) -> tuple[Path, Path, Path]:
    product, run = make_run(tmp_path)
    implementation = run / "implementation_v001"
    implementation.mkdir()
    (implementation / "method.py").write_bytes(b"def method():\n    return 1\n")
    experiment = run / "experiment_v001"
    experiment.mkdir()
    (experiment / "plan.md").write_bytes(b"# Plan\n\nreal attempt\n")
    return product, run, implementation


def _run(
    product: Path,
    run: Path,
    attempt_id: str,
    cwd: Path,
    command: list[str],
    *,
    inputs: tuple[Path, ...] = (),
    outputs: tuple[Path, ...] = (),
    env: dict[str, str] | None = None,
    timeout_seconds: float | None = None,
) -> subprocess.CompletedProcess[bytes]:
    argv = [
        sys.executable,
        str(RUNNER),
        "--product-root",
        str(product),
        "--run-root",
        str(run),
        "--version",
        "v001",
        "--attempt-id",
        attempt_id,
        "--cwd",
        str(cwd),
        "--seed-not-set",
        "--implementation-file",
        str(run / "implementation_v001" / "method.py"),
    ]
    for path in inputs:
        argv.extend(("--input", str(path)))
    for path in outputs:
        argv.extend(("--output", str(path)))
    if timeout_seconds is not None:
        argv.extend(("--timeout-seconds", str(timeout_seconds)))
    if not outputs:
        argv.append("--stdout-as-evidence")
    argv.extend(("--", *command))
    return subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)


def test_runner_captures_real_command_output_exit_code_and_files(tmp_path: Path) -> None:
    product, run, cwd = _fixture(tmp_path)
    script = cwd / "experiment.py"
    capture = run / "experiment_v001" / "attempts" / "attempt-001"
    output = capture / "result.txt"
    script.write_text(
        "from pathlib import Path\n"
        "import sys\n"
        "Path(sys.argv[1]).write_text('value=7', encoding='utf-8')\n"
        "print('stdout-value')\n"
        "print('stderr-value', file=sys.stderr)\n",
        encoding="utf-8",
    )
    completed = _run(
        product,
        run,
        "attempt-001",
        cwd,
        [sys.executable, str(script), str(output)],
        inputs=(script,),
        outputs=(output,),
    )
    assert completed.returncode == 0
    record = json.loads((capture / "execution.json").read_text(encoding="utf-8"))
    assert record["schema_version"] == 6
    assert record["command_exit_code"] == 0
    assert record["output_contract_ok"] is True
    assert record["cwd"] == str(cwd.resolve())
    assert "platform" in record["environment_facts"]
    assert (capture / "stdout.bin").read_bytes() in {b"stdout-value\r\n", b"stdout-value\n"}
    assert b"stderr-value" in (capture / "stderr.bin").read_bytes()


def test_explicit_timeout_does_not_change_a_successful_attempt(tmp_path: Path) -> None:
    product, run, cwd = _fixture(tmp_path)
    completed = _run(
        product,
        run,
        "attempt-001",
        cwd,
        [sys.executable, "-c", "print('finished')"],
        timeout_seconds=5,
    )

    assert completed.returncode == 0
    record = json.loads(
        (run / "experiment_v001/attempts/attempt-001/execution.json").read_text(
            encoding="utf-8"
        )
    )
    assert record["timed_out"] is False
    assert record["timeout_seconds"] == 5
    assert record["termination_method"] is None
    assert record["process_tree_cleanup_ok"] is None


@pytest.mark.windows
def test_timeout_records_failure_and_ends_spawned_child_process(tmp_path: Path) -> None:
    product, run, cwd = _fixture(tmp_path)
    capture = run / "experiment_v001/attempts/attempt-timeout"
    child_pid_path = capture / "child.pid"
    script = cwd / "spawn_child.py"
    script.write_text(
        "from pathlib import Path\n"
        "import subprocess, sys, time\n"
        "child = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(60)'])\n"
        "Path(sys.argv[1]).write_text(str(child.pid), encoding='utf-8')\n"
        "print('child-started', flush=True)\n"
        "time.sleep(60)\n",
        encoding="utf-8",
        newline="\n",
    )

    completed = _run(
        product,
        run,
        "attempt-timeout",
        cwd,
        [sys.executable, str(script), str(child_pid_path)],
        inputs=(script,),
        outputs=(child_pid_path,),
        timeout_seconds=0.5,
    )

    assert completed.returncode == 124
    record = json.loads((capture / "execution.json").read_text(encoding="utf-8"))
    assert record["timed_out"] is True
    assert record["timeout_seconds"] == 0.5
    assert isinstance(record["termination_method"], str)
    assert record["process_tree_cleanup_ok"] is True
    workspace = ResearchWorkspace(run, product_root=product)
    assert any(
        "timed_out" in error
        for error in experiment_material_errors(workspace, ("attempt-timeout",))
    )

    child_pid = int(child_pid_path.read_text(encoding="utf-8"))
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline and _windows_pid_exists(child_pid):
        time.sleep(0.1)
    assert not _windows_pid_exists(child_pid)


@pytest.mark.windows
def test_process_tree_cleanup_failure_is_reported(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class _StuckProcess:
        pid = 987654321

        @staticmethod
        def poll() -> None:
            return None

        @staticmethod
        def send_signal(_signal: int) -> None:
            raise OSError("signal unavailable")

        @staticmethod
        def wait(timeout: float) -> None:
            raise subprocess.TimeoutExpired("stuck", timeout)

    monkeypatch.setattr(
        runner_module.subprocess,
        "run",
        lambda *args, **kwargs: subprocess.CompletedProcess(args[0], 1),
    )

    method, cleanup_ok = runner_module._terminate_process_tree(_StuckProcess())

    assert method == "windows_taskkill_tree"
    assert cleanup_ok is False


def test_cleanup_failure_still_preserves_timeout_execution_record(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    product, run, cwd = _fixture(tmp_path)
    capture = run / "experiment_v001/attempts/attempt-timeout-cleanup-failed"
    monkeypatch.setattr(
        runner_module,
        "_terminate_process_tree",
        lambda _process: ("simulated_cleanup_failure", False),
    )

    code = runner_module.main(
        [
            "--product-root",
            str(product),
            "--run-root",
            str(run),
            "--version",
            "v001",
            "--attempt-id",
            "attempt-timeout-cleanup-failed",
            "--cwd",
            str(cwd),
            "--seed-not-set",
            "--implementation-file",
            str(run / "implementation_v001" / "method.py"),
            "--stdout-as-evidence",
            "--timeout-seconds",
            "0.05",
            "--",
            sys.executable,
            "-c",
            "import time; print('started', flush=True); time.sleep(0.5)",
        ]
    )

    assert code == 124
    record = json.loads((capture / "execution.json").read_text(encoding="utf-8"))
    assert record["timed_out"] is True
    assert record["termination_method"] == "simulated_cleanup_failure"
    assert record["process_tree_cleanup_ok"] is False
    assert (capture / "stdout.bin").is_file()
    assert (capture / "stderr.bin").is_file()
    workspace = ResearchWorkspace(run, product_root=product)
    assert experiment_material_errors(
        workspace, ("attempt-timeout-cleanup-failed",)
    )
    time.sleep(0.6)


def test_runner_refuses_to_overwrite_attempt_directory(tmp_path: Path) -> None:
    product, run, cwd = _fixture(tmp_path)
    capture = run / "experiment_v001" / "attempts" / "attempt-001"
    capture.mkdir(parents=True)
    completed = _run(
        product, run, "attempt-001", cwd, [sys.executable, "-c", "print('x')"]
    )
    assert completed.returncode == 2
    assert b"already exists" in completed.stderr


def test_nonempty_stdout_can_be_the_only_evidence_channel(tmp_path: Path) -> None:
    product, run, cwd = _fixture(tmp_path)
    completed = _run(
        product, run, "attempt-001", cwd, [sys.executable, "-c", "print('evidence')"]
    )
    assert completed.returncode == 0
    record = json.loads(
        (run / "experiment_v001/attempts/attempt-001/execution.json").read_text(
            encoding="utf-8"
        )
    )
    assert record["stdout_as_evidence"] is True
    assert record["evidence_contract_ok"] is True


def test_empty_stdout_without_output_cannot_be_evidence(tmp_path: Path) -> None:
    product, run, cwd = _fixture(tmp_path)
    completed = _run(
        product, run, "attempt-001", cwd, [sys.executable, "-c", "pass"]
    )
    assert completed.returncode == 2
    record = json.loads(
        (run / "experiment_v001/attempts/attempt-001/execution.json").read_text(
            encoding="utf-8"
        )
    )
    assert record["evidence_contract_ok"] is False


def test_missing_declared_output_is_mechanical_failure(tmp_path: Path) -> None:
    product, run, cwd = _fixture(tmp_path)
    capture = run / "experiment_v001" / "attempts" / "attempt-001"
    output = capture / "missing.txt"
    completed = _run(
        product,
        run,
        "attempt-001",
        cwd,
        [sys.executable, "-c", "print('ran')"],
        outputs=(output,),
    )
    assert completed.returncode == 2
    record = json.loads((capture / "execution.json").read_text(encoding="utf-8"))
    assert record["command_exit_code"] == 0
    assert record["output_contract_ok"] is False


def test_environment_secret_is_redacted_from_capture_and_console(tmp_path: Path) -> None:
    product, run, cwd = _fixture(tmp_path)
    secret = "sk-test-secret-value-123456789"
    env = os.environ.copy()
    env["CRL_TEST_API_KEY"] = secret
    script = "import os; print(os.environ['CRL_TEST_API_KEY'])"
    capture = run / "experiment_v001" / "attempts" / "attempt-001"
    completed = _run(
        product,
        run,
        "attempt-001",
        cwd,
        [sys.executable, "-c", script],
        env=env,
    )
    assert completed.returncode == 2
    combined = completed.stdout + completed.stderr
    combined += b"".join(path.read_bytes() for path in capture.iterdir() if path.is_file())
    assert secret.encode("utf-8") not in combined
    assert b"[REDACTED]" in (capture / "stdout.bin").read_bytes()


def test_secret_in_command_argument_is_rejected_before_execution(tmp_path: Path) -> None:
    product, run, cwd = _fixture(tmp_path)
    secret = "secret-value-123456"
    env = os.environ.copy()
    env["CRL_TEST_TOKEN"] = secret
    capture = run / "experiment_v001" / "attempts" / "attempt-001"
    completed = _run(
        product,
        run,
        "attempt-001",
        cwd,
        [sys.executable, "-c", "print('x')", secret],
        env=env,
    )
    assert completed.returncode == 2
    assert not capture.exists()
    assert secret.encode("utf-8") not in completed.stderr


def test_secret_bearing_declared_output_is_removed_but_facts_remain(tmp_path: Path) -> None:
    product, run, cwd = _fixture(tmp_path)
    secret = "sk-output-secret-value-123456789"
    env = os.environ.copy()
    env["CRL_TEST_API_KEY"] = secret
    capture = run / "experiment_v001/attempts/attempt-001"
    output = capture / "sensitive.bin"
    script = (
        "from pathlib import Path; import os,sys; "
        "Path(sys.argv[1]).write_bytes(b'prefix-' + os.environ['CRL_TEST_API_KEY'].encode())"
    )
    completed = _run(
        product,
        run,
        "attempt-001",
        cwd,
        [sys.executable, "-c", script, str(output)],
        outputs=(output,),
        env=env,
    )
    assert completed.returncode == 2
    assert not output.exists()
    record = json.loads((capture / "execution.json").read_text(encoding="utf-8"))
    after = record["outputs"][0]["after"]
    assert after["artifact_retained"] is False
    assert after["contains_possible_credential"] is True
    assert after["credential_detection"] == ["environment_secret", "credential_pattern"]
    assert isinstance(after["size_bytes"], int) and after["size_bytes"] > 0
    assert len(after["sha256"]) == 64
    assert secret.encode() not in (capture / "execution.json").read_bytes()


def test_secret_crossing_one_mebibyte_boundary_is_removed_and_redacted(
    tmp_path: Path,
) -> None:
    product, run, cwd = _fixture(tmp_path)
    secret = "sk-boundary-secret-value-123456789"
    env = os.environ.copy()
    env["CRL_TEST_API_KEY"] = secret
    capture = run / "experiment_v001/attempts/attempt-001"
    output = capture / "boundary.bin"
    script = (
        "from pathlib import Path; import os,sys; "
        "prefix=b'x'*(1024*1024-5); key=os.environ['CRL_TEST_API_KEY'].encode(); "
        "Path(sys.argv[1]).write_bytes(prefix+key); sys.stdout.buffer.write(prefix+key)"
    )
    completed = _run(
        product,
        run,
        "attempt-001",
        cwd,
        [sys.executable, "-c", script, str(output)],
        outputs=(output,),
        env=env,
    )
    assert completed.returncode == 2
    assert not output.exists()
    stdout = (capture / "stdout.bin").read_bytes()
    assert secret.encode() not in stdout
    assert b"[REDACTED]" in stdout


def test_large_capture_and_output_have_streamed_exact_file_facts(tmp_path: Path) -> None:
    product, run, cwd = _fixture(tmp_path)
    capture = run / "experiment_v001/attempts/attempt-001"
    output = capture / "large.bin"
    script = (
        "from pathlib import Path; import sys; data=(b'0123456789abcdef'*(700000)); "
        "Path(sys.argv[1]).write_bytes(data); sys.stdout.buffer.write(data)"
    )
    completed = _run(
        product,
        run,
        "attempt-001",
        cwd,
        [sys.executable, "-c", script, str(output)],
        outputs=(output,),
    )
    assert completed.returncode == 0
    record = json.loads((capture / "execution.json").read_text(encoding="utf-8"))
    import hashlib

    expected = hashlib.sha256(output.read_bytes()).hexdigest()
    assert record["outputs"][0]["after"]["sha256"] == expected
    assert record["capture"]["stdout"]["sha256"] == expected
    assert record["capture"]["stdout"]["size_bytes"] == output.stat().st_size


@pytest.mark.windows
def test_attempts_junction_is_rejected_before_external_capture(tmp_path: Path) -> None:
    product, run, cwd = _fixture(tmp_path)
    outside = tmp_path / "outside-attempts"
    make_directory_reparse_point(run / "experiment_v001/attempts", outside)
    completed = _run(
        product, run, "attempt-001", cwd, [sys.executable, "-c", "print('x')"]
    )
    assert completed.returncode == 2
    assert b"reparse point" in completed.stderr
    assert list(outside.iterdir()) == []


def test_seed_must_be_explicitly_nonempty_or_marked_not_set(tmp_path: Path) -> None:
    product, run, cwd = _fixture(tmp_path)
    argv = [
        sys.executable,
        str(RUNNER),
        "--product-root",
        str(product),
        "--run-root",
        str(run),
        "--version",
        "v001",
        "--attempt-id",
        "attempt-001",
        "--cwd",
        str(cwd),
        "--seed",
        "",
        "--implementation-file",
        str(run / "implementation_v001" / "method.py"),
        "--stdout-as-evidence",
        "--",
        sys.executable,
        "-c",
        "print('must not run')",
    ]
    completed = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    assert completed.returncode == 2
    assert b"non-empty explicit value" in completed.stderr
    assert not (run / "experiment_v001/attempts/attempt-001").exists()


def _windows_pid_exists(pid: int) -> bool:
    completed = subprocess.run(
        ["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"],
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        check=False,
    )
    return f'"{pid}"'.encode("ascii") in completed.stdout
