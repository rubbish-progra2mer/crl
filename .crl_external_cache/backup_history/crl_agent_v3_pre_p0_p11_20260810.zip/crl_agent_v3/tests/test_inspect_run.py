from __future__ import annotations

from pathlib import Path

from crl_v3.workspace import ResearchWorkspace
from tools.inspect_run import inspect_run
from conftest import make_file_symlink, make_run, record_successful_attempt


def _run(tmp_path: Path, status: str = "ACTIVE") -> Path:
    _, run = make_run(tmp_path, status=status)
    return run


def test_active_run_reports_facts_without_calling_incompleteness_failure(tmp_path: Path) -> None:
    run = _run(tmp_path)
    (run / "problem_v001.md").write_bytes(b"problem\n")
    report = inspect_run(run, product_root=run.parent)
    assert report["status"] == "ACTIVE"
    assert report["documents"]["problem_v001.md"]["exists"] is True
    assert report["errors"] == []
    assert report["warnings"] == []


def test_optional_empty_markdown_and_plan_only_are_not_research_failures(
    tmp_path: Path,
) -> None:
    run = _run(tmp_path)
    experiment = run / "experiment_v001"
    experiment.mkdir()
    (experiment / "plan.md").write_bytes(b"plan\n")
    (run / "memory_v001.md").write_bytes(b"")
    report = inspect_run(run, product_root=run.parent)
    assert report["experiment"]["attempt_count"] == 0
    assert not any("experiment material" in item for item in report["warnings"])
    assert not any("Markdown is empty" in item for item in report["errors"])


def test_inspect_reports_run_markdown_symlink_as_unsafe(tmp_path: Path) -> None:
    run = _run(tmp_path)
    outside = tmp_path / "outside.md"
    outside.write_text("outside\n", encoding="utf-8", newline="\n")
    make_file_symlink(run / "problem_v001.md", outside)
    report = inspect_run(run, product_root=run.parent)
    assert any("safe regular Run-local" in item for item in report["errors"])


def test_no_delivery_needs_only_matching_terminal_file(tmp_path: Path) -> None:
    run = _run(tmp_path, "CONCLUDED_NO_DELIVERY")
    (run / "NO_DELIVERY.md").write_bytes(
        b'# No-Go\n<!-- CRL_TERMINAL_META {"status":"CONCLUDED_NO_DELIVERY","version":"v001"} -->\n\nreason\n'
    )
    report = inspect_run(run, product_root=run.parent)
    assert report["terminal"] is True
    assert report["no_delivery_count"] == 1
    assert report["no_delivery_history"][0]["version"] == "v001"
    assert report["latest_no_delivery"]["path"] == "NO_DELIVERY.md"
    assert report["errors"] == []


def test_same_version_delivery_and_no_delivery_are_reported_as_conflict(
    tmp_path: Path,
) -> None:
    run = _run(tmp_path)
    workspace = ResearchWorkspace(run, product_root=run.parent)
    workspace.write_seed("# Seed\n\nvalidated")
    source = run / "workbench_v001" / "input.txt"
    source.parent.mkdir()
    source.write_text("evidence\n", encoding="utf-8", newline="\n")
    completed = record_successful_attempt(run.parent, run, "v001", source)
    assert completed.returncode == 0
    workspace.write_review_request("review", ["seed_v001.md"])
    for number in (1, 2, 3):
        workspace.write_reviewer_report(number, f"task-{number}", "opinion")
    workspace.write_review_decision("deliver")
    workspace.write_delivery(supporting_attempt_ids=("attempt-001",))
    (run / "NO_DELIVERY.md").write_bytes(
        b'# No-Go\n<!-- CRL_TERMINAL_META {"status":"CONCLUDED_NO_DELIVERY","version":"v001"} -->\n\nreason\n'
    )

    report = inspect_run(run, product_root=run.parent)

    assert any(
        "multiple scientific conclusions exist for one version" in error
        for error in report["errors"]
    )


def test_unverifiable_delivery_history_is_an_error(tmp_path: Path) -> None:
    run = _run(tmp_path)
    (run / "DELIVERY.md").write_bytes(
        b'# Delivery\n<!-- CRL_TERMINAL_META {"status":"DELIVERED","version":"v001"} -->\n\nseed\n'
    )
    report = inspect_run(run, product_root=run.parent)
    assert any("invalid Delivery history" in error for error in report["errors"])


def test_no_go_with_an_unverifiable_delivery_record_is_rejected(tmp_path: Path) -> None:
    run = _run(tmp_path, "CONCLUDED_NO_DELIVERY")
    (run / "DELIVERY.md").write_bytes(
        b'# Delivery\n<!-- CRL_TERMINAL_META {"status":"DELIVERED","version":"v001"} -->\n\nseed\n'
    )
    (run / "NO_DELIVERY.md").write_bytes(
        b'# No-Go\n<!-- CRL_TERMINAL_META {"status":"CONCLUDED_NO_DELIVERY","version":"v001"} -->\n\nreason\n'
    )
    report = inspect_run(run, product_root=run.parent)
    assert any("invalid Delivery history" in error for error in report["errors"])


def test_delivered_status_exposes_missing_mechanical_materials(tmp_path: Path) -> None:
    run = _run(tmp_path, "DELIVERED")
    (run / "DELIVERY.md").write_bytes(
        b'# Delivery\n<!-- CRL_TERMINAL_META {"status":"DELIVERED","version":"v001"} -->\n\nseed\n'
    )
    report = inspect_run(run, product_root=run.parent)
    assert report["errors"]
    assert any("metadata" in error.lower() for error in report["errors"])


def test_future_version_artifact_is_reported_instead_of_silently_selected(
    tmp_path: Path,
) -> None:
    run = _run(tmp_path)
    (run / "candidate_v002.md").write_text(
        "future\n", encoding="utf-8", newline="\n"
    )
    report = inspect_run(run, product_root=run.parent)
    assert report["status_current_version"] == "v001"
    assert report["current_version"] == "v001"
    assert "v002" in report["available_versions"]
    assert any("newer than RUN_STATUS" in error for error in report["errors"])


def test_binary_credential_heuristic_is_visible_as_warning(tmp_path: Path) -> None:
    run = _run(tmp_path)
    (run / "model.bin").write_bytes(b"label=password=abcdefgh")
    report = inspect_run(run, product_root=run.parent)
    assert any("model.bin" in warning for warning in report["warnings"])
    assert not any("model.bin" in error for error in report["errors"])
