# CRL Contract v2 Run 文件指南

本文说明文件类别和可写内容，帮助主 AI 研究者长期思考与接手现场。它不是阶段机、表单或交付评分标准；正式流程只见 `CRL.md`。

## 1. 控制文件

新 Run 由 `tools/manage_run.py start` 创建三个 UTF-8 无 BOM、LF 文件。

### `RUN_CHARTER.md`

保存不可漂移的 Run 身份和方向边界，至少包含：

```text
RUN_ID: YYYYMMDD_HHMM_runNN
CRL_CONTRACT_VERSION: 2
DEFAULT_DOMAIN: TEXT_AND_TOOL_LLM_AGENT
MODE: AUTONOMOUS 或 DIRECTED
CURRENT_VERSION: v001
```

自主 Run 的方向由主研究者在默认领域内选择；定向 Run 保存用户给出的更窄硬边界。

### `RUN_STATUS.md`

保存当前版本和客观生命周期。常用字段包括 `RUN_ID`、`STATUS`、`MODE`、`CURRENT_VERSION`、`LAST_DURABLE_ARTIFACT`、`NEXT_ACTION` 和更新时间。它方便接手，不是科研阶段状态机。

### `RUN_LEDGER.md`

简洁追加重要事实，例如创建、方向转向、版本推进、用户暂停、显式恢复、已有结论 Run 的继续，以及每次 Delivery、No-Go 或用户永久终止。不要重复全部研究正文；研究内容写入版本文档和 Seed。

## 2. 可选研究外部记忆

以下材料全部可用，但可省略、不检查章节、不规定顺序、不参与交付资格：

- `problem_vNNN.md`：问题、价值、边界和可证伪条件。
- `research_map_vNNN.md`：论文谱系、机制、Evidence 和未决问题。
- `nearest_prior_vNNN.md`：最近工作、组件差异和公平比较。
- `candidate_vNNN.md`：候选方法、改变的计算和风险。
- `evidence_packet_vNNN.md`：当前研究真正依赖的 Evidence 摘要。
- `selection_context_vNNN.md`：为何选择、放弃或转向；候选失败后可按需记录负面证据的实际杀伤层级、仍存的正交路线及转向理由。
- `memory_vNNN.md`：只供同一 Run 恢复的思考记忆；可按需记录当前假设、支持与反证、假设错误时的影响、已经形成的负面约束、仍存的正交路线及下一步检查，不新增独立假设账本。
- `failure_attribution_vNNN.md`：失败事实、已排除原因和归因边界。
- `workbench_vNNN/`：临时代码、草图、分析和非正式试验。
- `implementation_vNNN/`：准备绑定正式 attempt 的实现与配置。
- `experiment_vNNN/plan.md`：可选实验计划。
- `experiment_vNNN/result.md`：可选实验解释。

某类不适用时可以不创建，也可以写明原因。不得为通过脚本填充空洞内容。

## 3. 最终 Seed

准备交付的当前版本必须创建：

```text
seed_vNNN.md
```

Seed 是唯一最终科学正文，建议自足覆盖：

- 研究问题与价值；
- 文献依据、最近工作和最接近差异；
- 方法实际改变了什么计算或机制；
- 最小可证伪 Claim；
- 支撑实验及其能证明和不能证明的内容；
- 替代解释、失败边界和风险；
- 为什么值得扩大、下一步最有信息量的实验。

Seed 还应诚实说明证据成熟度：哪些结果只是机制一致性，哪一项评价依据不与方法构造同源并独立支持了核心 Claim，哪些问题仍属于扩大验证。仅仅值得做第一次决定性验证的方向可以继续保留为同轮候选，但不应包装成正式 Seed；“候选”不因此成为新文件或新状态。

同一 Run 中已经复现的核心反例不能只列作“未来工作”：后续版本应说明它已成为回归实验、已被收缩为外部信任前提，或为何方法范围变化使它不再适用。核心修复若改变研究对象、信任边界或主要计算，Seed 应采用重新核对后的邻接领域和最近工作定位。强基线应获得相同信息、工具能力和合理可比预算；反例、主回归和外部桥接实验分别披露分母，不混成一个总体比例。这些仍是科学表达建议，不是固定章节。

这些是科学表达建议，不是脚本检查章节。Seed 一旦形成送审请求，其确切字节即进入三审哈希链；需要修改时推进科学版本并重新三审。

## 4. 正式实验 attempt

直接支撑 Delivery 的 attempt 位于：

```text
experiment_vNNN/attempts/attempt-id/
├── execution.json
├── stdout.bin
├── stderr.bin
└── 声明输出
```

运行器命令需要至少一个 `--implementation-file`，并在 `--output` 与 `--stdout-as-evidence` 中至少选择一种证据通道。`--input` 可以重复，也可以没有；随机种子必须给出值或显式 `--seed-not-set`。

可选的 `--timeout-seconds POSITIVE_NUMBER` 为正式实验设置显式超时；不提供时保持无限制前台运行。超时 attempt 会保留 stdout、stderr 和 schema 6 执行记录，记录终止及进程树清理事实，并以退出码 124 结束，因此不能支撑 Delivery。已有 schema 5 attempt 继续可读，不迁移。

示意：

```powershell
& D:\Desktop\crl\env\crl_agent_v3\python.exe `
  D:\Desktop\crl\crl_agent_v3\tools\run_local_experiment.py `
  --product-root D:\Desktop\crl `
  --run-root D:\Desktop\crl\YYYYMMDD_HHMM_runNN `
  --version v001 `
  --attempt-id attempt-001 `
  --cwd D:\Desktop\crl\YYYYMMDD_HHMM_runNN\implementation_v001 `
  --implementation-file D:\Desktop\crl\YYYYMMDD_HHMM_runNN\implementation_v001\method.py `
  --stdout-as-evidence `
  --timeout-seconds 600 `
  --seed-not-set `
  -- D:\Desktop\crl\env\crl_agent_v3\python.exe method.py
```

科学充分性由主研究者判断；机械记录只证明命令事实、文件身份和证据通道。

## 5. Review 与 Decision

`review_vNNN/request.md` 是三位 Reviewer 的共同请求。通过 `tools/manage_review.py create-request` 创建，阅读清单必须包含 `seed_vNNN.md`，可追加其他当前版本 Markdown。请求元数据自动保存材料大小和 SHA-256。

请求形成后，分别为三个 Reviewer 调用同一条 `tools/manage_review.py render-input --product-root ... --run-root ... --version vNNN`，把其标准输出中的同一份已核验完整正文交给三个 fresh 上下文。命令不写 Run、不创建材料包；材料变化、缺失、越界或编码错误会直接拒绝输出。

报告保存为 `reviewer_1.md`、`reviewer_2.md`、`reviewer_3.md`，每份绑定同一 request SHA。主研究者随后写 `decision_vNNN.md`；其元数据绑定 request 与三份报告 SHA。科学正文可自由表达对意见的判断、证据成熟度、评价依据是否与方法构造同源、负面证据杀死的是当前候选还是更宽方向、是否仍有可信正交路线、下一步是第一次核心验证还是扩大验证，以及交付、No-Go 或继续研究的决定。这些内容没有固定章节，也不由脚本解析。

若决定继续研究，保留当前 Decision，推进版本并继续本 Run；用户明确继续一个已有交付或无交付结论的 Run 时，同样先核验全部历史、保留旧材料并推进版本。下一次准备交付时形成新版本 Seed，使用三位全新 Reviewer。无需为“继续”增加状态文件或新的终局类型。

## 6. 交付、无交付与永久结束

### `DELIVERY.md` 与 `DELIVERY_vNNN.md`

由程序生成，不手写科研正文。首次交付使用 `DELIVERY.md`；显式恢复后的后续交付使用当前科学版本对应的 `DELIVERY_vNNN.md`。每份记录只引用：

- 最终版本；
- Seed 路径与 SHA-256；
- Review request SHA-256；
- Decision SHA-256；
- 明确选中的支撑 attempt 标识。
- 每个支撑 attempt 的 `execution.json` SHA-256。

正式科研内容以 Seed 字节为准。旧交付记录、Seed、实验、三审和 Decision 保持原样，后续版本另写新材料。

### `NO_DELIVERY.md` 与 `NO_DELIVERY_vNNN.md`

主研究者自由解释为什么当前研究没有值得交付的种子。若无交付源于候选失败，可在正文任意合适位置说明负面证据为何不只否定当前候选或方法谱系，以及经过非机械正交转向复核后，剩余主要路线为何不值得继续投入；不规定章节、数量或穷尽证明，脚本不检查这些科研判断。首次无交付使用 `NO_DELIVERY.md`，后续无交付使用当前科学版本对应的 `NO_DELIVERY_vNNN.md`。无需 Seed、实验、三审或补齐其他可选文档。它只结束当前科学版本，已有交付和无交付历史均原样保留；用户可显式指定该 Run，核验历史后推进到下一版本继续。普通启动不会扫描或自动恢复。

### `TERMINATED_BY_USER.md`

只有用户明确要求永久终止时生成。用户仅想稍后继续时使用暂停，不生成终局。更早的交付和无交付记录均原样保留；该文件一旦形成，整个 Run 永不恢复。

`DELIVERED` 与 `CONCLUDED_NO_DELIVERY` 都阻止当前版本写入，但用户显式指定该 Run 后可核验全部结论历史并推进到下一版本；只有 `TERMINATED_BY_USER.md` 永久禁止恢复。同一版本不能同时存在交付和无交付结论。

## 7. 常用薄工具

```text
tools/manage_run.py start|advance-version|pause|terminate
tools/inspect_run.py
tools/run_local_experiment.py [--timeout-seconds ...]
tools/manage_review.py create-request|render-input|save-report|status
tools/query_knowledge.py cards|passages|hybrid|evidence|paper
```

这些工具管理文件和真实性。没有调用某个工具本身不能成为科研不合格的理由。
