from __future__ import annotations

import hashlib
import json
import math
import os
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable
from uuid import uuid4

from crl_v3.workspace import (
    ResearchWorkspace,
    _atomic_write_text,
    _required_file,
    _sha256,
    _validate_utf8_lf,
    safe_relative_path,
)


@dataclass(frozen=True, slots=True)
class ExperimentPlanDocument:
    path: str
    content: str
    sha256: str


@dataclass(frozen=True, slots=True)
class ExperimentArtifact:
    path: str
    relative_path: str
    area: str
    size_bytes: int
    sha256: str


@dataclass(frozen=True, slots=True)
class ExperimentResultDocument:
    path: str
    content: str
    sha256: str


def write_experiment_plan(
    workspace: ResearchWorkspace, content: str
) -> ExperimentPlanDocument:
    path = workspace.experiment_path / "plan.md"
    workspace._assert_narrative_mutable(path)
    data = _atomic_write_text(path, content, within=workspace.workspace_path)
    return ExperimentPlanDocument(str(path), data.decode("utf-8"), _sha256(data))


def read_experiment_plan(workspace: ResearchWorkspace) -> ExperimentPlanDocument:
    path = workspace.experiment_path / "plan.md"
    data = _read_required_markdown(workspace, path)
    return ExperimentPlanDocument(str(path), data.decode("utf-8"), _sha256(data))


def save_experiment_artifact(
    workspace: ResearchWorkspace,
    source: str | Path,
    relative_path: str,
    *,
    area: str = "experiment",
    replace: bool = False,
) -> ExperimentArtifact:
    workspace.assert_run_writable()
    source_path = Path(source).resolve()
    if not source_path.is_file():
        raise FileNotFoundError(source_path)
    relative = safe_relative_path(relative_path)
    roots = {
        "experiment": workspace.experiment_path,
        "implementation": workspace.implementation_path,
        "workbench": workspace.workbench_path,
    }
    if area not in roots:
        raise ValueError(f"unsupported artifact area: {area!r}")
    if replace and area != "workbench":
        raise ValueError("replace=True is only allowed for workbench artifacts")
    target = workspace.assert_write_target(roots[area] / relative)
    workspace._assert_narrative_mutable(target)
    if source_path == target.resolve():
        raise ValueError("artifact source and destination must differ")
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() and not replace:
        raise FileExistsError(f"experiment artifact already exists: {target}")
    temporary = target.with_name(f".{target.name}.{uuid4().hex}.tmp")
    try:
        with source_path.open("rb") as source_handle, temporary.open("xb") as target_handle:
            shutil.copyfileobj(source_handle, target_handle)
            target_handle.flush()
            os.fsync(target_handle.fileno())
        os.replace(temporary, target)
    finally:
        if temporary.exists():
            temporary.unlink()
    size_bytes, digest = _file_size_sha256(target)
    return ExperimentArtifact(
        path=str(target),
        relative_path=target.relative_to(workspace.workspace_path).as_posix(),
        area=area,
        size_bytes=size_bytes,
        sha256=digest,
    )


def write_experiment_result(
    workspace: ResearchWorkspace, content: str
) -> ExperimentResultDocument:
    path = workspace.experiment_path / "result.md"
    workspace._assert_narrative_mutable(path)
    data = _atomic_write_text(path, content, within=workspace.workspace_path)
    return ExperimentResultDocument(str(path), data.decode("utf-8"), _sha256(data))


def read_experiment_result(workspace: ResearchWorkspace) -> ExperimentResultDocument:
    path = workspace.experiment_path / "result.md"
    data = _read_required_markdown(workspace, path)
    return ExperimentResultDocument(str(path), data.decode("utf-8"), _sha256(data))


def list_experiment_files(workspace: ResearchWorkspace) -> tuple[ExperimentArtifact, ...]:
    artifacts: list[ExperimentArtifact] = []
    for area, root in (
        ("implementation", workspace.implementation_path),
        ("experiment", workspace.experiment_path),
        ("workbench", workspace.workbench_path),
    ):
        workspace.assert_write_target(root)
        if not root.is_dir():
            continue
        for path in sorted(item for item in root.rglob("*") if item.is_file()):
            workspace.assert_write_target(path)
            size_bytes, digest = _file_size_sha256(path)
            artifacts.append(
                ExperimentArtifact(
                    path=str(path),
                    relative_path=path.relative_to(workspace.workspace_path).as_posix(),
                    area=area,
                    size_bytes=size_bytes,
                    sha256=digest,
                )
            )
    return tuple(artifacts)


def experiment_material_errors(
    workspace: ResearchWorkspace,
    attempt_ids: Iterable[str] | None = None,
) -> tuple[str, ...]:
    errors: list[str] = []
    try:
        attempts = workspace.assert_write_target(
            workspace.experiment_path / "attempts"
        )
    except ValueError as error:
        return (f"invalid experiment attempts directory: {error}",)
    requested = None if attempt_ids is None else tuple(
        dict.fromkeys(_attempt_id(item) for item in attempt_ids)
    )
    if requested is not None and not requested:
        return ("at least one supporting attempt id is required",)
    attempt_dirs: list[Path] = []
    if requested is not None:
        for attempt_id in requested:
            try:
                attempt_dirs.append(
                    workspace.assert_write_target(attempts / attempt_id)
                )
            except ValueError as error:
                errors.append(f"invalid supporting attempt {attempt_id}: {error}")
    elif attempts.is_dir():
        for path in sorted(attempts.iterdir()):
            if path.is_dir():
                try:
                    workspace.assert_write_target(path)
                except ValueError:
                    continue
                attempt_dirs.append(path)
    if not attempt_dirs:
        errors.append(f"missing experiment attempt directory: {attempts}")
    elif requested is not None:
        for attempt in attempt_dirs:
            attempt_errors = _supporting_attempt_errors(workspace, attempt)
            if attempt_errors:
                errors.append(
                    f"invalid supporting attempt {attempt.name}: "
                    + "; ".join(attempt_errors)
                )
    else:
        attempt_results = [
            (attempt, _supporting_attempt_errors(workspace, attempt))
            for attempt in attempt_dirs
        ]
        if not any(not attempt_errors for _, attempt_errors in attempt_results):
            details = []
            for attempt, attempt_errors in attempt_results[:3]:
                summary = "; ".join(attempt_errors[:3]) or "not a supporting attempt"
                details.append(f"{attempt.name}: {summary}")
            errors.append(
                "no valid successful supporting experiment attempt: "
                + " | ".join(details)
            )
    return tuple(errors)


def valid_supporting_attempt_ids(workspace: ResearchWorkspace) -> tuple[str, ...]:
    try:
        attempts = workspace.assert_write_target(
            workspace.experiment_path / "attempts"
        )
    except ValueError:
        return ()
    if not attempts.is_dir():
        return ()
    valid = []
    for attempt in sorted(attempts.iterdir()):
        if not attempt.is_dir():
            continue
        try:
            workspace.assert_write_target(attempt)
        except ValueError:
            continue
        if not _supporting_attempt_errors(workspace, attempt):
            valid.append(attempt.name)
    return tuple(valid)


def file_fact(path: Path) -> dict[str, Any]:
    size_bytes, digest = _file_size_sha256(path)
    return {"path": str(path), "size_bytes": size_bytes, "sha256": digest}


def supporting_attempt_execution_sha256(
    workspace: ResearchWorkspace, attempt_id: str
) -> str:
    """Return the exact validated execution record identity for one attempt."""

    attempt = workspace.experiment_path / "attempts" / _attempt_id(attempt_id)
    errors = _supporting_attempt_errors(workspace, attempt)
    if errors:
        raise ValueError(
            f"invalid supporting attempt {attempt.name}: " + "; ".join(errors)
        )
    data = _required_file(
        attempt / "execution.json", within=workspace.workspace_path
    )
    return _sha256(data)


def _supporting_attempt_errors(
    workspace: ResearchWorkspace, attempt: Path
) -> tuple[str, ...]:
    errors: list[str] = []
    execution_path = attempt / "execution.json"
    try:
        execution_path = workspace.assert_read_target(execution_path)
    except ValueError as error:
        return (str(error),)
    except FileNotFoundError:
        return ("missing execution.json",)
    try:
        data = _required_file(execution_path, within=workspace.workspace_path)
        if len(data) > 4 * 1024 * 1024:
            raise ValueError("execution.json is unreasonably large")
        execution = json.loads(data.decode("utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError, ValueError) as error:
        return (f"invalid execution.json: {error}",)
    if not isinstance(execution, dict):
        return ("execution.json must contain an object",)

    schema_version = execution.get("schema_version")
    if schema_version not in {5, 6}:
        errors.append("execution schema_version is not supported")

    expected_scalars = {
        "run_root": str(workspace.workspace_path),
        "version": workspace.version,
        "attempt_id": attempt.name,
        "command_exit_code": 0,
        "runner_exit_code": 0,
        "command_error": None,
        "output_contract_ok": True,
        "evidence_contract_ok": True,
    }
    for name, expected in expected_scalars.items():
        if execution.get(name) != expected:
            errors.append(f"execution {name} does not equal {expected!r}")

    if schema_version == 6:
        timed_out = execution.get("timed_out")
        timeout_seconds = execution.get("timeout_seconds")
        termination_method = execution.get("termination_method")
        cleanup_ok = execution.get("process_tree_cleanup_ok")
        if type(timed_out) is not bool:
            errors.append("execution timed_out must be boolean")
        if timeout_seconds is not None and (
            type(timeout_seconds) not in {int, float}
            or not math.isfinite(timeout_seconds)
            or timeout_seconds <= 0
        ):
            errors.append("execution timeout_seconds must be null or positive")
        if timed_out is True:
            errors.append("execution timed_out is true")
            if timeout_seconds is None:
                errors.append("timed-out execution has no timeout_seconds")
            if not isinstance(termination_method, str) or not termination_method:
                errors.append("timed-out execution has no termination_method")
            if type(cleanup_ok) is not bool:
                errors.append("timed-out execution has no process_tree_cleanup_ok fact")
        else:
            if termination_method is not None:
                errors.append("non-timeout execution has a termination_method")
            if cleanup_ok is not None:
                errors.append("non-timeout execution has a process_tree_cleanup_ok fact")

    argv = execution.get("argv")
    if not isinstance(argv, list) or not argv or not all(
        isinstance(item, str) and item for item in argv
    ):
        errors.append("execution argv must be a non-empty string array")
    cwd_value = execution.get("cwd")
    if not isinstance(cwd_value, str):
        errors.append("execution cwd is missing")
    else:
        cwd = Path(cwd_value).resolve()
        if not cwd.is_dir() or not cwd.is_relative_to(workspace.workspace_path):
            errors.append("execution cwd is not an existing Run-local directory")
    environment = execution.get("environment_facts")
    if not isinstance(environment, dict) or not all(
        isinstance(environment.get(name), str) and environment[name]
        for name in ("platform", "python", "executable")
    ):
        errors.append("execution environment_facts are incomplete")
    seed = execution.get("seed")
    if not isinstance(seed, dict) or seed.get("status") not in {"set", "not_set"}:
        errors.append("execution seed must explicitly be set or not_set")
    elif seed.get("status") == "set" and not isinstance(seed.get("value"), str):
        errors.append("execution seed value must be text")

    implementation_files = execution.get("implementation_files")
    if not isinstance(implementation_files, list) or not implementation_files:
        errors.append("execution implementation_files must be a non-empty array")
    else:
        seen = set()
        implementation_root = workspace.implementation_path.resolve()
        for index, fact in enumerate(implementation_files):
            if not isinstance(fact, dict) or not isinstance(fact.get("path"), str):
                errors.append(f"implementation file {index} fact is invalid")
                continue
            try:
                relative = safe_relative_path(fact["path"])
                expected_path = workspace.assert_write_target(
                    workspace.workspace_path / relative
                )
            except ValueError as error:
                errors.append(f"implementation file {index} path is invalid: {error}")
                continue
            if expected_path in seen:
                errors.append(f"implementation file {index} is duplicated")
                continue
            seen.add(expected_path)
            if not expected_path.resolve().is_relative_to(implementation_root):
                errors.append(
                    f"implementation file {index} is outside current implementation directory"
                )
                continue
            errors.extend(
                _recorded_file_errors(
                    workspace,
                    fact,
                    expected_path,
                    f"implementation file {index}",
                    require_recorded_path=False,
                    require_nonempty=True,
                )
            )

    capture = execution.get("capture")
    if not isinstance(capture, dict):
        errors.append("execution capture is missing")
    else:
        for name in ("stdout", "stderr"):
            expected_path = attempt / f"{name}.bin"
            errors.extend(
                _recorded_file_errors(
                    workspace,
                    capture.get(name),
                    expected_path,
                    name,
                    require_run_local=True,
                )
            )

    stdout_as_evidence = execution.get("stdout_as_evidence")
    if type(stdout_as_evidence) is not bool:
        errors.append("execution stdout_as_evidence must be boolean")

    inputs = execution.get("inputs")
    if not isinstance(inputs, list):
        errors.append("execution inputs must be an array")
    else:
        for index, fact in enumerate(inputs):
            if not isinstance(fact, dict) or not isinstance(fact.get("path"), str):
                errors.append(f"input {index} fact is invalid")
                continue
            errors.extend(
                _recorded_file_errors(
                    workspace,
                    fact,
                    Path(fact["path"]),
                    f"input {index}",
                )
            )

    outputs = execution.get("outputs")
    retained_nonempty_output = False
    if not isinstance(outputs, list):
        errors.append("execution outputs must be an array")
    else:
        for index, fact in enumerate(outputs):
            if not isinstance(fact, dict) or not isinstance(fact.get("path"), str):
                errors.append(f"output {index} fact is invalid")
                continue
            output_path = Path(fact["path"]).resolve()
            if not output_path.is_relative_to(attempt.resolve()):
                errors.append(f"output {index} is outside its attempt")
                continue
            after = fact.get("after")
            if not isinstance(after, dict) or after.get("exists") is not True:
                errors.append(f"output {index} was not retained")
                continue
            if after.get("contains_possible_credential") is not False:
                errors.append(f"output {index} contains a possible credential")
            if after.get("artifact_retained") is not True:
                errors.append(f"output {index} is not marked as retained")
            if isinstance(after.get("size_bytes"), int) and after["size_bytes"] > 0:
                retained_nonempty_output = retained_nonempty_output or (
                    after.get("artifact_retained") is True
                    and after.get("contains_possible_credential") is False
                )
            errors.extend(
                _recorded_file_errors(
                    workspace,
                    after,
                    output_path,
                    f"output {index}",
                    require_recorded_path=False,
                    require_run_local=True,
                )
            )
    stdout_evidence = False
    if isinstance(capture, dict) and isinstance(capture.get("stdout"), dict):
        stdout = capture["stdout"]
        stdout_evidence = bool(
            stdout_as_evidence is True
            and isinstance(stdout.get("size_bytes"), int)
            and stdout["size_bytes"] > 0
            and stdout.get("redaction_applied") is False
        )
    if not (stdout_evidence or retained_nonempty_output):
        errors.append("attempt has no retained non-empty evidence channel")
    return tuple(errors)


def _recorded_file_errors(
    workspace: ResearchWorkspace,
    fact: object,
    expected_path: Path,
    label: str,
    *,
    require_recorded_path: bool = True,
    require_nonempty: bool = False,
    require_run_local: bool = False,
) -> tuple[str, ...]:
    if not isinstance(fact, dict):
        return (f"{label} file fact is missing",)
    errors = []
    recorded_path = fact.get("path")
    if require_recorded_path and not isinstance(recorded_path, str):
        errors.append(f"{label} recorded path is missing")
    elif require_recorded_path and recorded_path is not None and (
        not isinstance(recorded_path, str)
        or Path(recorded_path).resolve() != expected_path.resolve()
    ):
        errors.append(f"{label} path does not match")
    lexical = Path(os.path.abspath(expected_path))
    if lexical.is_relative_to(workspace.workspace_path):
        try:
            expected_path = workspace.assert_read_target(lexical)
        except ValueError as error:
            return (f"{label} path is unsafe: {error}",)
        except FileNotFoundError:
            return (f"{label} file is missing",)
    else:
        if require_run_local:
            return (f"{label} file is outside the Run",)
        expected_path = lexical
    if not expected_path.is_file():
        errors.append(f"{label} file is missing")
        return tuple(errors)
    actual = file_fact(expected_path)
    if require_nonempty and actual["size_bytes"] <= 0:
        errors.append(f"{label} file is empty")
    if fact.get("size_bytes") != actual["size_bytes"]:
        errors.append(f"{label} size does not match")
    if fact.get("sha256") != actual["sha256"]:
        errors.append(f"{label} SHA-256 does not match")
    return tuple(errors)


def _attempt_id(value: str) -> str:
    text = str(value).strip()
    relative = safe_relative_path(text)
    if len(relative.parts) != 1 or not text:
        raise ValueError(f"attempt id must be one safe path component: {value!r}")
    return text


def _file_size_sha256(path: Path) -> tuple[int, str]:
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            size += len(chunk)
            digest.update(chunk)
    return size, digest.hexdigest()


def _read_required_markdown(
    workspace: ResearchWorkspace, path: Path
) -> bytes:
    try:
        data = _required_file(path, within=workspace.workspace_path)
    except FileNotFoundError as error:
        raise FileNotFoundError(f"missing experiment document: {path}") from error
    if not data or not data.decode("utf-8", errors="ignore").strip():
        raise ValueError(f"empty experiment document: {path}")
    _validate_utf8_lf(data, str(path))
    return data
