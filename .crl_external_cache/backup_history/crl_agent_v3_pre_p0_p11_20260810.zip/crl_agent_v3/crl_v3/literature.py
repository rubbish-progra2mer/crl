from __future__ import annotations

import hashlib
import json
import os
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, urlopen
from uuid import uuid4


_SEARCH_URL = "https://api.semanticscholar.org/graph/v1/paper/search"
_ARXIV_SEARCH_URL = "https://export.arxiv.org/api/query"
_SEARCH_FIELDS = ",".join(
    (
        "paperId",
        "title",
        "authors",
        "year",
        "venue",
        "externalIds",
        "abstract",
        "url",
        "openAccessPdf",
    )
)
_USER_AGENT = "crl-agent-v3/3.0.0-dev0"
_CHUNK_SIZE = 64 * 1024
_ATOM = "http://www.w3.org/2005/Atom"
_ARXIV = "http://arxiv.org/schemas/atom"
_XML_NAMESPACES = {"atom": _ATOM, "arxiv": _ARXIV}


@dataclass(frozen=True, slots=True)
class LiteratureCandidate:
    source: str
    source_id: str
    title: str | None
    authors: tuple[str, ...]
    year: int | None
    venue: str | None
    doi: str | None
    abstract: str | None
    landing_page_url: str | None
    pdf_url: str | None
    source_order: int


@dataclass(frozen=True, slots=True)
class PdfDownload:
    path: Path
    sha256: str
    byte_count: int


def search_semantic_scholar(
    query: str, limit: int, *, timeout: float = 30.0
) -> tuple[LiteratureCandidate, ...]:
    if not query.strip():
        raise ValueError("Search query must not be empty")
    if limit <= 0:
        raise ValueError("Search limit must be positive")

    parameters = urlencode(
        {"query": query, "limit": str(limit), "fields": _SEARCH_FIELDS}
    )
    request = Request(
        f"{_SEARCH_URL}?{parameters}",
        headers={"Accept": "application/json", "User-Agent": _USER_AGENT},
    )
    with urlopen(request, timeout=timeout) as response:
        payload = json.loads(response.read().decode("utf-8"))

    records = payload.get("data") or []
    return tuple(
        _candidate(record, source_order)
        for source_order, record in enumerate(records[:limit], start=1)
    )


def search_arxiv(
    query: str, limit: int, *, timeout: float = 30.0
) -> tuple[LiteratureCandidate, ...]:
    if not query.strip():
        raise ValueError("Search query must not be empty")
    if limit <= 0:
        raise ValueError("Search limit must be positive")

    parameters = urlencode(
        {"search_query": f"all:{query}", "start": "0", "max_results": str(limit)}
    )
    request = Request(
        f"{_ARXIV_SEARCH_URL}?{parameters}",
        headers={"Accept": "application/atom+xml", "User-Agent": _USER_AGENT},
    )
    with urlopen(request, timeout=timeout) as response:
        root = ET.fromstring(response.read())

    entries = root.findall("atom:entry", _XML_NAMESPACES)
    return tuple(
        _arxiv_candidate(entry, source_order)
        for source_order, entry in enumerate(entries[:limit], start=1)
    )


def download_pdf(
    pdf_url: str, target_path: str | Path, *, timeout: float = 60.0
) -> PdfDownload:
    if urlsplit(pdf_url).scheme not in {"http", "https"}:
        raise ValueError("PDF URL must use HTTP or HTTPS")

    target = Path(target_path).resolve()
    if target.exists():
        raise FileExistsError(target)
    if not target.parent.is_dir():
        raise FileNotFoundError(target.parent)

    temporary = target.parent / f".{target.name}.{uuid4().hex}.tmp"
    digest = hashlib.sha256()
    byte_count = 0
    request = Request(
        pdf_url,
        headers={"Accept": "application/pdf", "User-Agent": _USER_AGENT},
    )
    try:
        with urlopen(request, timeout=timeout) as response:
            first_chunk = response.read(_CHUNK_SIZE)
            if not first_chunk.startswith(b"%PDF-"):
                raise ValueError("Downloaded content does not have a PDF header")
            with temporary.open("xb") as stream:
                chunk = first_chunk
                while chunk:
                    stream.write(chunk)
                    digest.update(chunk)
                    byte_count += len(chunk)
                    chunk = response.read(_CHUNK_SIZE)
                stream.flush()
                os.fsync(stream.fileno())
        if target.exists():
            raise FileExistsError(target)
        os.replace(temporary, target)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise

    return PdfDownload(path=target, sha256=digest.hexdigest(), byte_count=byte_count)


def _candidate(record: dict[str, object], source_order: int) -> LiteratureCandidate:
    external_ids = record.get("externalIds") or {}
    open_access_pdf = record.get("openAccessPdf") or {}
    authors = record.get("authors") or []
    year = record.get("year")
    return LiteratureCandidate(
        source="Semantic Scholar",
        source_id=str(record.get("paperId") or ""),
        title=_optional_text(record.get("title")),
        authors=tuple(
            name
            for author in authors
            if (name := _optional_text(author.get("name"))) is not None
        ),
        year=year if isinstance(year, int) else None,
        venue=_optional_text(record.get("venue")),
        doi=_optional_text(external_ids.get("DOI")),
        abstract=_optional_text(record.get("abstract")),
        landing_page_url=_optional_text(record.get("url")),
        pdf_url=_optional_text(open_access_pdf.get("url")),
        source_order=source_order,
    )


def _arxiv_candidate(
    entry: ET.Element, source_order: int
) -> LiteratureCandidate:
    entry_id = _normalized_text(entry.findtext("atom:id", namespaces=_XML_NAMESPACES))
    published = _normalized_text(
        entry.findtext("atom:published", namespaces=_XML_NAMESPACES)
    )
    landing_page_url = None
    pdf_url = None
    for link in entry.findall("atom:link", _XML_NAMESPACES):
        href = _optional_text(link.get("href"))
        if link.get("rel") == "alternate" and link.get("type") == "text/html":
            landing_page_url = href
        if link.get("type") == "application/pdf":
            pdf_url = href

    source_id = ""
    if entry_id is not None:
        path = urlsplit(entry_id).path
        if path.startswith("/abs/"):
            source_id = path.removeprefix("/abs/")

    return LiteratureCandidate(
        source="arXiv",
        source_id=source_id,
        title=_normalized_text(
            entry.findtext("atom:title", namespaces=_XML_NAMESPACES)
        ),
        authors=tuple(
            name
            for author in entry.findall("atom:author", _XML_NAMESPACES)
            if (
                name := _normalized_text(
                    author.findtext("atom:name", namespaces=_XML_NAMESPACES)
                )
            )
            is not None
        ),
        year=(
            int(published[:4])
            if published is not None and published[:4].isdigit()
            else None
        ),
        venue=_normalized_text(
            entry.findtext("arxiv:journal_ref", namespaces=_XML_NAMESPACES)
        ),
        doi=_normalized_text(
            entry.findtext("arxiv:doi", namespaces=_XML_NAMESPACES)
        ),
        abstract=_normalized_text(
            entry.findtext("atom:summary", namespaces=_XML_NAMESPACES)
        ),
        landing_page_url=landing_page_url or entry_id,
        pdf_url=pdf_url,
        source_order=source_order,
    )


def _optional_text(value: object) -> str | None:
    return value if isinstance(value, str) and value else None


def _normalized_text(value: str | None) -> str | None:
    return " ".join(value.split()) if value and value.split() else None
