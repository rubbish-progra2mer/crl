from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Sequence

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from crl_v3.decision import (
    delivery_record_paths,
    no_delivery_record_paths,
    read_delivery_history,
    read_no_delivery_history,
    read_review_decision,
    read_terminal,
    secret_scan_warnings,
)
from crl_v3.experiment import valid_supporting_attempt_ids
from crl_v3.review import list_reviewer_reports, read_review_request, review_material_errors
from crl_v3.workspace import (
    CURRENT_CONTRACT_VERSION,
    PERMANENT_TERMINAL_FILE_STATUS,
    ResearchWorkspace,
    _assert_read_target,
    _is_reparse_point,
    _required_file,
    bind_run,
    contract_version,
)


_VERSION_PATTERN = re.compile(r"^v\d{3,}$")
_VERSION_IN_NAME = re.compile(r"(?:^|_)(v\d{3,})(?:\.md|$)")
_PERMANENT_TERMINAL_STATUSES = set(PERMANENT_TERMINAL_FILE_STATUS.values())
_CLOSED_STATUSES = _PERMANENT_TERMINAL_STATUSES | {
    "DELIVERED",
    "CONCLUDED_NO_DELIVERY",
}


def inspect_run(
    run_root: str | Path,
    version: str | None = None,
    *,
    product_root: str | Path | None = None,
) -> dict[str, Any]:
    if product_root is None:
        raise ValueError("product_root is required; it must not be inferred from run_root")
    product = Path(product_root).resolve(strict=True)
    root = bind_run(product, run_root)
    fields = _read_fields(root / "RUN_STATUS.md", root)
    status_current_version = fields.get("CURRENT_VERSION", "v001")
    current_version = version or status_current_version
    if not _VERSION_PATTERN.fullmatch(status_current_version):
        raise ValueError(f"invalid RUN_STATUS.md CURRENT_VERSION: {status_current_version!r}")
    if not _VERSION_PATTERN.fullmatch(current_version):
        raise ValueError(f"invalid CURRENT_VERSION: {current_version!r}")
    declared_status = fields.get("STATUS", "UNKNOWN")
    run_contract = contract_version(root)
    delivery_paths = list(delivery_record_paths(root))
    no_delivery_paths = list(no_delivery_record_paths(root))
    permanent_terminal_paths = [
        root / name
        for name in PERMANENT_TERMINAL_FILE_STATUS
        if (root / name).is_file()
    ]
    effective_status = declared_status
    if len(permanent_terminal_paths) == 1:
        effective_status = PERMANENT_TERMINAL_FILE_STATUS[
            permanent_terminal_paths[0].name
        ]

    report: dict[str, Any] = {
        "run_root": str(root),
        "run_id": fields.get("RUN_ID", root.name),
        "contract_version": run_contract,
        "current_contract": run_contract == CURRENT_CONTRACT_VERSION,
        "legacy_read_only": run_contract != CURRENT_CONTRACT_VERSION,
        "declared_status": declared_status,
        "effective_status": effective_status,
        "status": effective_status,
        "mode": fields.get("MODE"),
        "current_version": current_version,
        "status_current_version": status_current_version,
        "available_versions": sorted(_run_versions(root)),
        "terminal": effective_status in _CLOSED_STATUSES,
        "delivery_count": len(delivery_paths),
        "delivery_history": [],
        "latest_delivery": None,
        "no_delivery_count": len(no_delivery_paths),
        "no_delivery_history": [],
        "latest_no_delivery": None,
        "documents": {},
        "directories": {},
        "experiment": {},
        "review": {},
        "errors": [],
        "warnings": [],
    }
    if run_contract != CURRENT_CONTRACT_VERSION:
        report["warnings"].append(
            "legacy Run is maintenance-readable only and cannot enter current CRL operations"
        )
        legacy_documents = (
            "RUN_CHARTER.md",
            "RUN_STATUS.md",
            "RUN_LEDGER.md",
            "DELIVERY.md",
            "NO_DELIVERY.md",
            *PERMANENT_TERMINAL_FILE_STATUS,
        )
        for name in legacy_documents:
            report["documents"][name] = _file_fact(root / name, root)
        for path in delivery_paths[1:]:
            report["documents"][path.name] = _file_fact(path, root)
        for path in no_delivery_paths[1:]:
            report["documents"][path.name] = _file_fact(path, root)
        _append_markdown_integrity(root, report)
        if len(permanent_terminal_paths) > 1:
            report["errors"].append("multiple permanent terminal documents exist")
        elif permanent_terminal_paths and declared_status != effective_status:
            report["errors"].append(
                "RUN_STATUS.md disagrees with the authoritative terminal document"
            )
        report["errors"] = list(dict.fromkeys(report["errors"]))
        report["warnings"] = list(dict.fromkeys(report["warnings"]))
        return report

    workspace = ResearchWorkspace(root, version=current_version, product_root=product)
    future_versions = [
        item
        for item in report["available_versions"]
        if int(item[1:]) > int(status_current_version[1:])
    ]
    if future_versions:
        report["errors"].append(
            "Run has version artifacts newer than RUN_STATUS.md CURRENT_VERSION: "
            + ", ".join(future_versions)
        )
    report["warnings"].extend(secret_scan_warnings(root))
    for stem in (
        "problem",
        "research_map",
        "nearest_prior",
        "candidate",
        "evidence_packet",
        "selection_context",
        "decision",
        "memory",
        "failure_attribution",
        "seed",
    ):
        path = workspace.document_path(stem)
        report["documents"][path.name] = _file_fact(path, root)
    for path in (
        workspace.implementation_path,
        workspace.experiment_path,
        workspace.review_path,
        workspace.workbench_path,
    ):
        report["directories"][path.name] = _directory_fact(path, root)
    report["documents"]["DELIVERY.md"] = _file_fact(root / "DELIVERY.md", root)
    for path in delivery_paths[1:]:
        report["documents"][path.name] = _file_fact(path, root)
    report["documents"]["NO_DELIVERY.md"] = _file_fact(
        root / "NO_DELIVERY.md", root
    )
    for path in no_delivery_paths[1:]:
        report["documents"][path.name] = _file_fact(path, root)
    for name in PERMANENT_TERMINAL_FILE_STATUS:
        report["documents"][name] = _file_fact(root / name, root)
    _append_markdown_integrity(root, report)

    experiment_exists = workspace.experiment_path.is_dir()
    attempts_root = workspace.experiment_path / "attempts"
    attempt_count = 0
    if attempts_root.is_dir() and not _is_reparse_point(attempts_root):
        attempt_count = sum(
            1
            for item in attempts_root.iterdir()
            if item.is_dir() and not _is_reparse_point(item)
        )
    report["experiment"] = {
        "exists": experiment_exists,
        "attempt_count": attempt_count,
        "valid_attempt_ids": list(valid_supporting_attempt_ids(workspace)) if experiment_exists else [],
    }

    try:
        request = read_review_request(workspace)
        reports = list_reviewer_reports(workspace)
        decision = read_review_decision(workspace) if workspace.document_path("decision").is_file() else None
        report["review"] = {
            "request_exists": True,
            "reading_paths": list(request.reading_paths),
            "request_sha256": request.sha256,
            "materials": [
                {
                    "path": item.path,
                    "size_bytes": item.size_bytes,
                    "sha256": item.sha256,
                }
                for item in request.materials
            ],
            "reviewer_count": len(reports),
            "reviewer_ids": [item.reviewer_id for item in reports],
            "reviewer_request_sha256s": [item.request_sha256 for item in reports],
            "reviewer_report_sha256s": [item.sha256 for item in reports],
            "decision_exists": decision is not None,
            "decision_request_sha256": decision.request_sha256 if decision else None,
            "decision_report_sha256s": list(decision.report_sha256s) if decision else [],
            "material_errors": list(review_material_errors(workspace)),
        }
    except (OSError, UnicodeError, ValueError) as error:
        report["review"] = {
            "request_exists": (workspace.review_path / "request.md").is_file(),
            "material_errors": [str(error)],
        }

    delivery_history = ()
    try:
        delivery_history = read_delivery_history(workspace)
        report["delivery_history"] = [
            {
                "path": Path(item.path).relative_to(root).as_posix(),
                "version": item.version,
                "sha256": item.sha256,
            }
            for item in delivery_history
        ]
        report["delivery_count"] = len(delivery_history)
        report["latest_delivery"] = (
            report["delivery_history"][-1] if report["delivery_history"] else None
        )
    except (OSError, UnicodeError, ValueError) as error:
        if delivery_paths:
            report["errors"].append(f"invalid Delivery history: {error}")

    no_delivery_history = ()
    try:
        no_delivery_history = read_no_delivery_history(workspace)
        report["no_delivery_history"] = [
            {
                "path": Path(item.path).relative_to(root).as_posix(),
                "version": item.version,
                "sha256": item.sha256,
            }
            for item in no_delivery_history
        ]
        report["no_delivery_count"] = len(no_delivery_history)
        report["latest_no_delivery"] = (
            report["no_delivery_history"][-1]
            if report["no_delivery_history"]
            else None
        )
    except (OSError, UnicodeError, ValueError) as error:
        if no_delivery_paths:
            report["errors"].append(f"invalid No-Delivery history: {error}")

    conclusions = sorted(
        (*delivery_history, *no_delivery_history),
        key=lambda item: int(item.version[1:]),
    )
    conclusion_versions = [item.version for item in conclusions]
    if len(conclusion_versions) != len(set(conclusion_versions)):
        report["errors"].append(
            "multiple scientific conclusions exist for one version"
        )
    latest_conclusion = conclusions[-1] if conclusions else None

    if len(permanent_terminal_paths) > 1:
        report["errors"].append("multiple permanent terminal documents exist")
    elif permanent_terminal_paths:
        terminal = permanent_terminal_paths[0]
        try:
            read_terminal(
                terminal,
                PERMANENT_TERMINAL_FILE_STATUS[terminal.name],
                status_current_version,
            )
        except (OSError, UnicodeError, ValueError) as error:
            report["errors"].append(str(error))
    elif declared_status in _PERMANENT_TERMINAL_STATUSES:
        report["errors"].append(
            "RUN_STATUS.md declares a terminal status but no terminal document exists"
        )

    if permanent_terminal_paths and declared_status != effective_status:
        report["errors"].append(
            "RUN_STATUS.md disagrees with the authoritative terminal document"
        )
    if declared_status == "DELIVERED":
        if permanent_terminal_paths:
            report["errors"].append(
                "DELIVERED status conflicts with a permanent terminal document"
            )
        if latest_conclusion is None or latest_conclusion.status != "DELIVERED":
            report["errors"].append(
                "RUN_STATUS.md declares DELIVERED but the latest conclusion is not Delivery"
            )
        elif latest_conclusion.version != status_current_version:
            report["errors"].append(
                "latest Delivery version disagrees with RUN_STATUS.md CURRENT_VERSION"
            )
    elif declared_status == "CONCLUDED_NO_DELIVERY":
        if permanent_terminal_paths:
            report["errors"].append(
                "CONCLUDED_NO_DELIVERY conflicts with a permanent terminal document"
            )
        if (
            latest_conclusion is None
            or latest_conclusion.status != "CONCLUDED_NO_DELIVERY"
        ):
            report["errors"].append(
                "RUN_STATUS.md declares CONCLUDED_NO_DELIVERY but the latest "
                "conclusion is not No-Delivery"
            )
        elif latest_conclusion.version != status_current_version:
            report["errors"].append(
                "latest No-Delivery version disagrees with RUN_STATUS.md CURRENT_VERSION"
            )
    elif latest_conclusion and declared_status in {"ACTIVE", "PAUSED_BY_USER"}:
        if int(status_current_version[1:]) <= int(latest_conclusion.version[1:]):
            report["errors"].append(
                "an active or paused Run must be newer than its latest scientific conclusion"
            )
    if (
        declared_status == "TERMINATED_BY_USER"
        and latest_conclusion is not None
        and int(status_current_version[1:]) <= int(latest_conclusion.version[1:])
    ):
        report["errors"].append(
            "user termination version must be newer than prior scientific conclusions"
        )

    report["errors"] = list(dict.fromkeys(report["errors"]))
    report["warnings"] = list(dict.fromkeys(report["warnings"]))
    return report


def _append_markdown_integrity(root: Path, report: dict[str, Any]) -> None:
    for path in sorted(root.rglob("*.md")):
        fact = _file_fact(path, root)
        relative = path.relative_to(root).as_posix()
        if fact.get("unsafe"):
            report["errors"].append(
                f"Markdown is not a safe regular Run-local file: {relative}"
            )
            continue
        if not fact.get("utf8", False):
            report["errors"].append(f"Markdown is not valid UTF-8: {relative}")
        if fact.get("bom"):
            report["errors"].append(f"Markdown has a UTF-8 BOM: {relative}")
        if fact.get("lf_only") is False:
            report["errors"].append(f"Markdown does not use LF-only newlines: {relative}")


def _read_fields(path: Path, run_root: Path) -> dict[str, str]:
    fact = _file_fact(path, run_root)
    if not fact["exists"]:
        raise FileNotFoundError(path)
    if not fact.get("utf8") or fact.get("bom") or fact.get("lf_only") is False:
        raise ValueError(f"invalid Run status encoding or newline format: {path}")
    fields: dict[str, str] = {}
    data = _required_file(path, within=run_root)
    for line in data.decode("utf-8").splitlines():
        key, separator, value = line.partition(":")
        if separator and key.strip():
            fields[key.strip()] = value.strip()
    return fields


def _file_fact(path: Path, run_root: Path) -> dict[str, Any]:
    try:
        safe_path = _assert_read_target(path, run_root)
    except FileNotFoundError:
        return {"exists": False, "bytes": None}
    except (OSError, ValueError) as error:
        return {
            "exists": path.exists() or path.is_symlink(),
            "bytes": None,
            "unsafe": str(error),
        }
    fact: dict[str, Any] = {
        "exists": True,
        "bytes": safe_path.stat().st_size,
    }
    if safe_path.suffix.casefold() == ".md":
        data = safe_path.read_bytes()
        fact["bom"] = data.startswith(b"\xef\xbb\xbf")
        fact["lf_only"] = b"\r" not in data
        fact["nonempty"] = bool(data)
        try:
            data.decode("utf-8")
            fact["utf8"] = True
        except UnicodeDecodeError:
            fact["utf8"] = False
    return fact


def _directory_fact(path: Path, run_root: Path) -> dict[str, Any]:
    if not path.is_dir():
        return {"exists": False, "file_count": 0}
    if _is_reparse_point(path):
        return {"exists": True, "file_count": 0, "unsafe": "reparse point"}
    count = 0
    unsafe = 0
    for item in path.rglob("*"):
        if not item.is_file():
            continue
        try:
            _assert_read_target(item, run_root)
            count += 1
        except (OSError, ValueError):
            unsafe += 1
    fact = {"exists": True, "file_count": count}
    if unsafe:
        fact["unsafe_file_count"] = unsafe
    return fact


def _run_versions(run_root: Path) -> set[str]:
    versions: set[str] = set()
    for path in run_root.iterdir():
        versions.update(
            match.group(1) for match in _VERSION_IN_NAME.finditer(path.name)
        )
    return versions


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Inspect objective file facts for one CRL Run.")
    parser.add_argument("--product-root", required=True, type=Path)
    parser.add_argument("--run-root", required=True, type=Path)
    parser.add_argument("--version")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    arguments = build_parser().parse_args(argv)
    try:
        report = inspect_run(
            arguments.run_root,
            arguments.version,
            product_root=arguments.product_root,
        )
    except (OSError, UnicodeError, ValueError) as error:
        print(f"inspect_run: {error}", file=sys.stderr)
        return 2
    print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    return 1 if report["errors"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
