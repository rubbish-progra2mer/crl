from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import platform
import re
import signal
import subprocess
import sys
import tempfile
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Sequence

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from crl_v3.decision import (
    SecretScan,
    contains_secret,
    environment_secrets,
    redact_file,
    redact_secrets,
    scan_secret_bytes,
)
from crl_v3.experiment import file_fact
from crl_v3.workspace import ResearchWorkspace


SCHEMA_VERSION = 6
TIMEOUT_EXIT_CODE = 124
_TERMINATION_GRACE_SECONDS = 5.0
_ATTEMPT_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$")


def _utc_now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def _positive_seconds(value: str) -> float:
    try:
        seconds = float(value)
    except ValueError as error:
        raise argparse.ArgumentTypeError("timeout must be a positive number") from error
    if not math.isfinite(seconds) or seconds <= 0:
        raise argparse.ArgumentTypeError("timeout must be a positive number")
    return seconds


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run one foreground experiment inside a bound CRL Run attempt."
    )
    parser.add_argument("--product-root", required=True, type=Path)
    parser.add_argument("--run-root", required=True, type=Path)
    parser.add_argument("--version", required=True)
    parser.add_argument("--attempt-id", required=True)
    parser.add_argument("--cwd", required=True, type=Path)
    parser.add_argument(
        "--implementation-file", action="append", required=True, type=Path
    )
    parser.add_argument("--input", action="append", default=[], type=Path)
    parser.add_argument("--output", action="append", default=[], type=Path)
    parser.add_argument("--stdout-as-evidence", action="store_true")
    parser.add_argument("--timeout-seconds", type=_positive_seconds)
    seed = parser.add_mutually_exclusive_group(required=True)
    seed.add_argument("--seed")
    seed.add_argument("--seed-not-set", action="store_true")
    parser.add_argument("argv", nargs=argparse.REMAINDER)
    return parser


def _parse_args(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = build_parser()
    arguments = parser.parse_args(argv)
    if arguments.argv[:1] == ["--"]:
        arguments.argv = arguments.argv[1:]
    if not arguments.argv:
        parser.error("an executable and its arguments are required after --")
    if not arguments.output and not arguments.stdout_as_evidence:
        parser.error("declare at least one --output or use --stdout-as-evidence")
    return arguments


def main(argv: Sequence[str] | None = None) -> int:
    secrets = environment_secrets()
    raw_arguments = tuple(sys.argv[1:] if argv is None else argv)
    try:
        _reject_secret_values(raw_arguments, secrets)
        arguments = _parse_args(argv)
        if _ATTEMPT_ID.fullmatch(arguments.attempt_id) is None:
            raise ValueError("attempt-id must be a safe 1-80 character identifier")
        if arguments.seed is not None and not arguments.seed.strip():
            raise ValueError("--seed must contain a non-empty explicit value")
        workspace = ResearchWorkspace(
            arguments.run_root,
            version=arguments.version,
            product_root=arguments.product_root,
        )
        workspace.assert_run_writable()
        cwd = arguments.cwd.resolve()
        implementation_files = [path.resolve() for path in arguments.implementation_file]
        inputs = [path.resolve() for path in arguments.input]
        outputs = [path.resolve() for path in arguments.output]
        capture_dir = workspace.experiment_path / "attempts" / arguments.attempt_id
        _validate_paths(
            workspace, capture_dir, cwd, implementation_files, inputs, outputs
        )
        capture_dir.mkdir(parents=True)
        for output in outputs:
            output.parent.mkdir(parents=True, exist_ok=True)
    except (OSError, UnicodeError, ValueError) as error:
        message = redact_secrets(str(error).encode("utf-8", errors="replace"), secrets)
        print("run_local_experiment: " + message.decode("utf-8", errors="replace"), file=sys.stderr)
        return 2

    implementation_facts = []
    for path in implementation_files:
        fact = file_fact(path)
        fact["path"] = path.relative_to(workspace.workspace_path).as_posix()
        implementation_facts.append(fact)
    input_facts = [file_fact(path) for path in inputs]
    output_facts: list[dict[str, Any]] = [
        {"path": str(path), "before": {"exists": False}} for path in outputs
    ]
    started_at = _utc_now()
    timer = time.perf_counter()
    timed_out = False
    termination_method: str | None = None
    process_tree_cleanup_ok: bool | None = None
    stdout_path = workspace.assert_write_target(capture_dir / "stdout.bin")
    stderr_path = workspace.assert_write_target(capture_dir / "stderr.bin")
    with tempfile.TemporaryDirectory(
        prefix="crl-experiment-capture-", ignore_cleanup_errors=True
    ) as temporary:
        raw_stdout = Path(temporary) / "stdout.raw"
        raw_stderr = Path(temporary) / "stderr.raw"
        try:
            with raw_stdout.open("xb") as stdout_handle, raw_stderr.open(
                "xb"
            ) as stderr_handle:
                popen_options: dict[str, Any] = {}
                if os.name == "nt":
                    popen_options["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
                else:
                    popen_options["start_new_session"] = True
                process = subprocess.Popen(
                    arguments.argv,
                    cwd=cwd,
                    shell=False,
                    stdout=stdout_handle,
                    stderr=stderr_handle,
                    **popen_options,
                )
                try:
                    command_exit_code = process.wait(timeout=arguments.timeout_seconds)
                    command_error: str | None = None
                except subprocess.TimeoutExpired:
                    timed_out = True
                    termination_method, process_tree_cleanup_ok = _terminate_process_tree(
                        process
                    )
                    command_exit_code = process.returncode
                    command_error = (
                        "TimeoutExpired: experiment exceeded "
                        f"{arguments.timeout_seconds:g} seconds"
                    )
        except OSError as error:
            command_error = f"{type(error).__name__}: {error}"
            command_exit_code = None
            if not raw_stdout.exists():
                raw_stdout.write_bytes(b"")
            raw_stderr.write_bytes(str(error).encode("utf-8", errors="replace"))
        stdout_redacted = redact_file(raw_stdout, stdout_path, secrets)
        stderr_redacted = redact_file(raw_stderr, stderr_path, secrets)
    duration = time.perf_counter() - timer
    finished_at = _utc_now()

    output_contract_ok = True
    for fact, output in zip(output_facts, outputs, strict=True):
        if output.is_file():
            workspace.assert_write_target(output)
            after, scan = _file_fact_and_scan(output, secrets)
            after.pop("path")
            detection = []
            if scan.environment_secret:
                detection.append("environment_secret")
            if scan.heuristic_pattern:
                detection.append("credential_pattern")
            retained = not scan.contains_possible_credential
            fact["after"] = {
                "exists": True,
                **after,
                "contains_possible_credential": scan.contains_possible_credential,
                "credential_detection": detection,
                "artifact_retained": retained,
            }
            if not retained:
                output_contract_ok = False
                _remove_sensitive_output(output)
        else:
            output_contract_ok = False
            fact["after"] = {
                "exists": output.exists(),
                "kind": "directory" if output.is_dir() else "missing",
            }

    if command_error is not None:
        command_error = redact_secrets(
            command_error.encode("utf-8", errors="replace"), secrets
        ).decode("utf-8", errors="replace")
    stdout_fact = file_fact(stdout_path)
    stdout_evidence_ok = bool(
        arguments.stdout_as_evidence
        and stdout_fact["size_bytes"] > 0
        and not stdout_redacted
    )
    output_evidence_ok = any(
        isinstance(fact.get("after"), dict)
        and fact["after"].get("artifact_retained") is True
        and isinstance(fact["after"].get("size_bytes"), int)
        and fact["after"]["size_bytes"] > 0
        for fact in output_facts
    )
    evidence_contract_ok = stdout_evidence_ok or output_evidence_ok
    runner_exit_code = TIMEOUT_EXIT_CODE if timed_out else (
        command_exit_code
        if command_exit_code not in (None, 0)
        else (
            0
            if command_exit_code == 0
            and output_contract_ok
            and evidence_contract_ok
            else 2
        )
    )
    execution = {
        "schema_version": SCHEMA_VERSION,
        "run_root": str(workspace.workspace_path),
        "version": workspace.version,
        "attempt_id": arguments.attempt_id,
        "argv": arguments.argv,
        "cwd": str(cwd),
        "started_at_utc": started_at,
        "finished_at_utc": finished_at,
        "duration_seconds": duration,
        "command_exit_code": command_exit_code,
        "runner_exit_code": runner_exit_code,
        "command_error": command_error,
        "timed_out": timed_out,
        "timeout_seconds": arguments.timeout_seconds,
        "termination_method": termination_method,
        "process_tree_cleanup_ok": process_tree_cleanup_ok,
        "seed": (
            {"status": "not_set"}
            if arguments.seed_not_set
            else {"status": "set", "value": arguments.seed}
        ),
        "implementation_files": implementation_facts,
        "inputs": input_facts,
        "outputs": output_facts,
        "output_contract_ok": output_contract_ok,
        "stdout_as_evidence": arguments.stdout_as_evidence,
        "evidence_contract_ok": evidence_contract_ok,
        "capture": {
            "stdout": {**stdout_fact, "redaction_applied": stdout_redacted},
            "stderr": {**file_fact(stderr_path), "redaction_applied": stderr_redacted},
        },
        "environment_facts": {
            "platform": platform.platform(),
            "python": sys.version,
            "executable": sys.executable,
        },
    }
    execution_data = (
        json.dumps(execution, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    ).encode("utf-8")
    if contains_secret(execution_data, secrets):
        execution_data = redact_secrets(execution_data, secrets)
        execution = json.loads(execution_data.decode("utf-8"))
        runner_exit_code = 2
        execution["runner_exit_code"] = runner_exit_code
        execution_data = (
            json.dumps(execution, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
        ).encode("utf-8")
    execution_path = workspace.assert_write_target(capture_dir / "execution.json")
    execution_path.write_bytes(execution_data)
    print(json.dumps(execution, ensure_ascii=False, sort_keys=True))
    return int(runner_exit_code)


def _terminate_process_tree(process: subprocess.Popen[Any]) -> tuple[str, bool]:
    if process.poll() is not None:
        return "already_exited_after_timeout", True
    if os.name == "nt":
        method = "windows_ctrl_break"
        try:
            process.send_signal(signal.CTRL_BREAK_EVENT)
        except (OSError, ValueError):
            method = "windows_taskkill_tree"
        else:
            try:
                process.wait(timeout=_TERMINATION_GRACE_SECONDS)
                return method, True
            except subprocess.TimeoutExpired:
                method = "windows_ctrl_break_then_taskkill_tree"
        try:
            killed = subprocess.run(
                ["taskkill", "/PID", str(process.pid), "/T", "/F"],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=_TERMINATION_GRACE_SECONDS,
                check=False,
            )
            process.wait(timeout=_TERMINATION_GRACE_SECONDS)
            return method, killed.returncode == 0 and process.poll() is not None
        except (OSError, subprocess.TimeoutExpired):
            return method, False

    method = "posix_sigterm_group"
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except (OSError, ProcessLookupError):
        if process.poll() is not None:
            return "already_exited_after_timeout", True
    try:
        process.wait(timeout=_TERMINATION_GRACE_SECONDS)
        return method, True
    except subprocess.TimeoutExpired:
        method = "posix_sigterm_then_sigkill_group"
    try:
        os.killpg(process.pid, signal.SIGKILL)
        process.wait(timeout=_TERMINATION_GRACE_SECONDS)
        return method, process.poll() is not None
    except (OSError, ProcessLookupError, subprocess.TimeoutExpired):
        return method, False


def _validate_paths(
    workspace: ResearchWorkspace,
    capture_dir: Path,
    cwd: Path,
    implementation_files: list[Path],
    inputs: list[Path],
    outputs: list[Path],
) -> None:
    if capture_dir.exists():
        raise ValueError(f"attempt directory already exists: {capture_dir}")
    attempts_root = workspace.assert_write_target(
        workspace.experiment_path / "attempts"
    )
    workspace.assert_write_target(capture_dir)
    if capture_dir.parent != attempts_root:
        raise ValueError("attempt directory must be a direct child of the current attempts directory")
    workspace.assert_write_target(cwd)
    if not cwd.is_dir() or not cwd.is_relative_to(workspace.workspace_path):
        raise ValueError("cwd must be an existing directory inside the bound Run")
    implementation_root = workspace.implementation_path.resolve()
    seen_implementation: set[Path] = set()
    for path in implementation_files:
        workspace.assert_write_target(path)
        if (
            not path.is_file()
            or path.stat().st_size <= 0
            or not path.is_relative_to(implementation_root)
        ):
            raise ValueError(
                "implementation-file must be a non-empty file inside the current "
                f"implementation directory: {path}"
            )
        if path in seen_implementation:
            raise ValueError(f"duplicate implementation-file: {path}")
        seen_implementation.add(path)
    for path in inputs:
        if not path.is_file():
            raise ValueError(f"input is not an existing file: {path}")
    for path in outputs:
        workspace.assert_write_target(path)
        if not path.is_relative_to(capture_dir):
            raise ValueError(f"declared output must be inside this attempt directory: {path}")
        if path.exists():
            raise ValueError(f"output already exists before execution: {path}")


def _reject_secret_values(values: Sequence[str], secrets: tuple[bytes, ...]) -> None:
    rendered = "\0".join(str(item) for item in values).encode("utf-8", errors="ignore")
    if contains_secret(rendered, secrets):
        raise ValueError("command-line arguments or paths contain a possible credential")


def _file_fact_and_scan(
    path: Path, secrets: tuple[bytes, ...]
) -> tuple[dict[str, Any], SecretScan]:
    digest = hashlib.sha256()
    size = 0
    overlap = max(max((len(value) for value in secrets), default=0) + 8, 8192)
    tail = b""
    exact = False
    heuristic = False
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            size += len(chunk)
            digest.update(chunk)
            scan = scan_secret_bytes(tail + chunk, secrets)
            exact = exact or scan.environment_secret
            heuristic = heuristic or scan.heuristic_pattern
            tail = (tail + chunk)[-overlap:]
    return (
        {"path": str(path), "size_bytes": size, "sha256": digest.hexdigest()},
        SecretScan(exact, heuristic),
    )


def _remove_sensitive_output(path: Path) -> None:
    try:
        path.unlink()
    except OSError:
        with path.open("wb") as handle:
            handle.flush()
            os.fsync(handle.fileno())
        path.unlink(missing_ok=True)
    if path.exists():
        raise OSError(f"could not remove credential-bearing output: {path}")


if __name__ == "__main__":
    raise SystemExit(main())
